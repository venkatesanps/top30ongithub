#!/usr/bin/env python3
"""Extract a normalized intermediate representation (IR) from Mermaid text.

Trust boundary: this program parses bounded text. It never evaluates, renders,
fetches, or executes Mermaid, JavaScript, URLs, directives, or label content.
Every label and directive value is untrusted data. Click targets and styling are
counted and discarded; retained labels are emitted only as inert text.

Supported grammars are flowchart/graph, sequenceDiagram, stateDiagram-v2 (or
its older stateDiagram header), and erDiagram. Inputs may be .mmd, .mermaid, or
Markdown files containing fenced ``mermaid`` blocks.

Usage:
    python3 mermaid_extract.py <file> [--diagram N|all] [--json]
                               [--max-rows N] [--out PATH]

Exit codes: 0 success, 2 unreadable, unsupported, malformed, or over limits.
"""

from __future__ import annotations

import argparse
import html
import json
import re
import sys
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, NoReturn


MAX_SOURCE_BYTES = 4 * 1024 * 1024
MAX_NODES = 2000
MAX_EDGES = 5000
# One logical flowchart statement, whether it spans lines or shares a line
# with others. Real statements are a few hundred characters at most; the cap
# keeps per-statement parsing work bounded.
MAX_STATEMENT_CHARS = 4096
# Sequence `autonumber` start and step. Mermaid numbers steps with JS numbers,
# which stay exact up to 15 digits. Checking the length first also keeps the
# error the same on Pythons with and without an int-from-string digit limit.
MAX_AUTONUMBER_DIGITS = 15
SUPPORTED_KINDS = "flowchart, sequenceDiagram, stateDiagram-v2, erDiagram"
UNSUPPORTED_KINDS = {
    "pie",
    "mindmap",
    "gitgraph",
    "quadrantchart",
    "timeline",
    "c4context",
    "sankey",
    "sankey-beta",
    "gantt",
    "journey",
    "classdiagram",
}
MARKDOWN_SUFFIXES = {".md", ".markdown", ".mdown", ".mkd"}
MERMAID_SUFFIXES = {".mmd", ".mermaid"}
# ER entity names start with a letter (any script) or underscore. The regex
# shapes the token; _er_name enforces the first character, because \w also
# matches non-decimal numerals such as "²" and "½" that \d does not exclude.
ER_IDENTIFIER = r"[^\W\d][\w.-]*"


def _er_name(name: str) -> bool:
    return name[:1] == "_" or name[:1].isalpha()


# A quoted ER name may hold spaces and any character except these, as in
# Mermaid's ER lexer. Mermaid drops the quotes to get the entity name.
ER_QUOTED_NAME = r'"[^"%\r\n\v\b\\]+"'
ER_NAME = rf"(?:{ER_QUOTED_NAME}|{ER_IDENTIFIER})"

# Mermaid's ER cardinality tokens, each with the symbol it draws at the
# (left, right) end of a relationship. Mermaid reads the words as
# case-insensitive aliases for the symbols.
_ER_ZERO_OR_ONE = ("|o", "o|")
_ER_ONLY_ONE = ("||", "||")
_ER_ZERO_OR_MORE = ("}o", "o{")
_ER_ONE_OR_MORE = ("}|", "|{")
ER_CARDINALITIES = {
    "|o": _ER_ZERO_OR_ONE,
    "o|": _ER_ZERO_OR_ONE,
    "zero or one": _ER_ZERO_OR_ONE,
    "one or zero": _ER_ZERO_OR_ONE,
    "||": _ER_ONLY_ONE,
    "1": _ER_ONLY_ONE,
    "one": _ER_ONLY_ONE,
    "only one": _ER_ONLY_ONE,
    "}o": _ER_ZERO_OR_MORE,
    "o{": _ER_ZERO_OR_MORE,
    "0+": _ER_ZERO_OR_MORE,
    "many": _ER_ZERO_OR_MORE,
    "many(0)": _ER_ZERO_OR_MORE,
    "zero or more": _ER_ZERO_OR_MORE,
    "zero or many": _ER_ZERO_OR_MORE,
    "}|": _ER_ONE_OR_MORE,
    "|{": _ER_ONE_OR_MORE,
    "1+": _ER_ONE_OR_MORE,
    "many(1)": _ER_ONE_OR_MORE,
    "one or more": _ER_ONE_OR_MORE,
    "one or many": _ER_ONE_OR_MORE,
    "u": ("u", "u"),
}
# Identifying relationships draw solid (`--`), non-identifying ones dashed (`..`).
ER_IDENTIFICATIONS = {
    "--": "--",
    "to": "--",
    "..": "..",
    ".-": "..",
    "-.": "..",
    "optionally to": "..",
}
# Mermaid reads `1` as a cardinality only right before a link or before a
# spaced word, and `u` (its MD_PARENT end) only right before `.`, `-` or `|`.
_ER_TOKEN_CONTEXT = {
    "1": r"1(?=\s+[A-Za-z_\"'0-9]|--|\.\.|\.-|-\.)",
    "u": r"u(?=[.|-])",
}


def _er_tokens(tokens: dict[str, object]) -> str:
    """Return a regex alternation over tokens, longest first like Mermaid's lexer.

    As in Mermaid (jison), a token that ends in a word character must end at a
    word boundary, so `to` does not match the start of `tomany`. Mermaid ignores
    only ASCII case, so `(?a:...)` keeps `İ` and `ı` from matching `i`.
    """
    ordered = sorted(tokens, key=len, reverse=True)
    return "|".join(
        _ER_TOKEN_CONTEXT.get(token, "(?a:" + re.escape(token) + (r"\b" if token[-1].isalnum() else "") + ")")
        for token in ordered
    )


ER_CARDINALITY = _er_tokens(ER_CARDINALITIES)
ER_IDENTIFICATION = _er_tokens(ER_IDENTIFICATIONS)


def _er_entity(token: str) -> str | None:
    """Return the entity name of an ER name token, or None if it is not one."""
    if token.startswith('"'):
        return token[1:-1]
    return token if _er_name(token) else None


def _configure_stdout_utf8() -> None:
    """Emit digests as UTF-8 even when Windows selects a legacy codepage."""
    reconfigure = getattr(sys.stdout, "reconfigure", None)
    if reconfigure is not None:
        reconfigure(encoding="utf-8", errors="strict")


class ExtractError(Exception):
    """An input the extractor refuses. `main()` reports it and exits 2."""


def _fail(message: str) -> NoReturn:
    raise ExtractError(message)


@dataclass
class Node:
    id: str
    label: str = ""
    shape: str = "rect"
    parent: str | None = None
    depth: int = 0
    container: bool = False
    children: list[str] = field(default_factory=list)
    fields: list[str] = field(default_factory=list)
    in_degree: int = 0
    out_degree: int = 0


@dataclass
class Edge:
    id: str
    source: str
    target: str
    label: str = ""
    style: str = "solid"
    arrowhead: str = "arrow"
    bidirectional: bool = False
    undirected: bool = False
    order: int = 0


@dataclass
class Diagram:
    index: int
    kind: str
    source_line: int
    direction: str = "TD"
    nodes: list[Node] = field(default_factory=list)
    edges: list[Edge] = field(default_factory=list)
    fragments: list[dict[str, Any]] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    # Sequence `autonumber` directives: step numbers are content, prose cites them.
    autonumber: list[dict[str, Any]] = field(default_factory=list)
    discarded: dict[str, int] = field(
        default_factory=lambda: {"style_directives": 0, "click_handlers": 0, "config_directives": 0}
    )
    _nodes_by_id: dict[str, Node] = field(default_factory=dict, init=False, repr=False)
    _state_descriptions: dict[str, list[str]] = field(default_factory=dict, init=False, repr=False)

    @property
    def node_map(self) -> dict[str, Node]:
        return self._nodes_by_id

    def add_node(
        self,
        node_id: str,
        label: str = "",
        shape: str = "",
        parent: str | None = None,
        container: bool = False,
    ) -> Node:
        existing = self._nodes_by_id.get(node_id)
        if existing is not None:
            if label and (label != node_id or existing.label == existing.id):
                existing.label = label
                if label != node_id:
                    self._state_descriptions.pop(node_id, None)
            if shape:
                existing.shape = shape
            if parent is not None and existing.parent is None:
                existing.parent = parent
                existing.depth = self._depth_for(parent)
                self._attach(parent, node_id)
            existing.container = existing.container or container
            return existing
        if len(self.nodes) >= MAX_NODES:
            _fail(f"node limit exceeded (max {MAX_NODES})")
        node = Node(
            id=node_id,
            label=label or node_id,
            shape=shape or "rect",
            parent=parent,
            depth=self._depth_for(parent),
            container=container,
        )
        self.nodes.append(node)
        self._nodes_by_id[node_id] = node
        if parent is not None:
            self._attach(parent, node_id)
        return node

    def _depth_for(self, parent: str | None) -> int:
        if parent is None:
            return 0
        parent_node = self._nodes_by_id.get(parent)
        return (parent_node.depth + 1) if parent_node is not None else 1

    def _attach(self, parent: str, child: str) -> None:
        parent_node = self._nodes_by_id.get(parent)
        if parent_node is not None and child not in parent_node.children:
            parent_node.children.append(child)
            parent_node.container = True

    def add_edge(
        self,
        source: str,
        target: str,
        label: str = "",
        style: str = "solid",
        arrowhead: str = "arrow",
        bidirectional: bool = False,
        undirected: bool = False,
    ) -> Edge:
        if len(self.edges) >= MAX_EDGES:
            _fail(f"edge limit exceeded (max {MAX_EDGES})")
        edge = Edge(
            id=f"e{len(self.edges) + 1}",
            source=source,
            target=target,
            label=label,
            style=style,
            arrowhead=arrowhead,
            bidirectional=bidirectional,
            undirected=undirected,
            order=len(self.edges) + 1,
        )
        self.edges.append(edge)
        return edge


@dataclass
class SourceBlock:
    index: int
    text: str
    source_line: int


def clean_label(value: str) -> str:
    """Flatten Mermaid label markup without interpreting it."""
    text = value.strip()
    if len(text) >= 2 and text[0] == text[-1] and text[0] in "\"'`":
        text = text[1:-1]
    if text.startswith("`") and text.endswith("`"):
        text = text[1:-1]
    text = re.sub(r"<br\s*/?>", "\n", text, flags=re.IGNORECASE)
    text = re.sub(r"<[^>]+>", "", text)
    text = re.sub(r"\*\*(.*?)\*\*", r"\1", text)
    text = re.sub(r"__(.*?)__", r"\1", text)
    text = re.sub(r"(?<!\w)[*_](.*?)[*_](?!\w)", r"\1", text)
    text = text.replace("\\\"", '"').replace("\\'", "'")

    def entity_reference(match: re.Match[str]) -> str:
        entity = match.group(1)
        if entity.isdecimal():
            try:
                codepoint = int(entity, 10)
            except ValueError:
                return match.group(0)
            if not 0 < codepoint <= 0x10FFFF or 0xD800 <= codepoint <= 0xDFFF:
                return match.group(0)
            return f"&#{entity};"
        if entity + ";" in html.entities.html5:
            return f"&{entity};"
        return match.group(0)

    text = re.sub(r"(?<!&)#([0-9]+|[A-Za-z][A-Za-z0-9]*);", entity_reference, text)
    text = html.unescape(text)
    return "\n".join(part.strip() for part in text.splitlines()).strip()


def _read_bounded(path: Path) -> str:
    try:
        with path.open("rb") as source:
            data = source.read(MAX_SOURCE_BYTES + 1)
    except OSError as error:
        _fail(f"{path}: {error}")
    if len(data) > MAX_SOURCE_BYTES:
        _fail(
            f"source exceeds the {MAX_SOURCE_BYTES // (1024 * 1024)} MiB limit"
        )
    try:
        return data.decode("utf-8-sig")
    except UnicodeDecodeError:
        _fail(f"{path.name}: source is not valid UTF-8 text")


def load_blocks(path: Path) -> list[SourceBlock]:
    suffix = path.suffix.casefold()
    if suffix not in MERMAID_SUFFIXES | MARKDOWN_SUFFIXES:
        _fail(f"{path.name}: not a Mermaid file")
    source = _read_bounded(path)
    if suffix in MERMAID_SUFFIXES:
        return [SourceBlock(0, source, 1)]

    blocks: list[SourceBlock] = []
    lines = source.splitlines()
    start: int | None = None
    fence = ""
    content: list[str] = []
    capture = False
    for line_number, line in enumerate(lines, 1):
        if start is None:
            match = re.match(r"^\s*(`{3,}|~{3,})(.*)$", line)
            if (match and not (match.group(1)[0] == "`" and "`" in match.group(2))
                    and (match.group(2).strip().casefold() == "mermaid"
                         or re.match(r"^ {0,3}[`~]", line))):
                start = line_number + 1
                fence = match.group(1)
                capture = match.group(2).strip().casefold() == "mermaid"
                content = []
            continue
        if (re.match(rf"^\s*{re.escape(fence[0])}{{{len(fence)},}}\s*$", line)
                and (capture or re.match(r"^ {0,3}[`~]", line))):
            if capture:
                blocks.append(SourceBlock(len(blocks), "\n".join(content), start))
            start = None
            fence = ""
            content = []
        elif capture:
            content.append(line)
    if start is not None and capture:
        _fail(f"{path.name}: unterminated mermaid fence starting at line {start - 1}")
    if not blocks:
        _fail(f"{path.name}: no fenced mermaid block found")
    return blocks


FRONTMATTER_MAX_LINES = 40


def _frontmatter_end(lines: list[str]) -> int:
    """Return the last line index of a leading `---` frontmatter block, or -1."""
    first = next(
        (index for index, line in enumerate(lines) if line.strip()),
        None,
    )
    if first is None or lines[first].strip() != "---":
        return -1
    limit = min(len(lines), first + FRONTMATTER_MAX_LINES + 1)
    for index in range(first + 1, limit):
        if lines[index].strip() == "---":
            return index
    return -1


def _prepared_lines(block: SourceBlock) -> tuple[list[tuple[int, str]], int]:
    """Blank out comments and config, returning the lines and the number of config directives."""
    prepared: list[tuple[int, str]] = []
    in_directive = False
    lines = block.text.splitlines()
    frontmatter_end = _frontmatter_end(lines)
    config_directives = 1 if frontmatter_end >= 0 else 0
    for offset, raw in enumerate(lines):
        line_number = block.source_line + offset
        stripped = raw.strip()
        if offset <= frontmatter_end:
            # Mermaid's `--- title: ... ---` frontmatter is source config; the
            # redraw discards it the same way it discards `%%{init}%%`.
            prepared.append((line_number, ""))
            continue
        if in_directive:
            if "}%%" in stripped:
                in_directive = False
            prepared.append((line_number, ""))
            continue
        if stripped.startswith("%%{"):
            config_directives += 1
            if "}%%" not in stripped:
                in_directive = True
            prepared.append((line_number, ""))
            continue
        if stripped.startswith("%%"):
            prepared.append((line_number, ""))
            continue
        prepared.append((line_number, raw.rstrip()))
    return prepared, config_directives


def _kind_and_direction(
    lines: list[tuple[int, str]],
) -> tuple[str, str, int]:
    for position, (line_number, raw) in enumerate(lines):
        text = raw.strip()
        if not text:
            continue
        match = re.match(r"^(flowchart|graph)\s+(TD|TB|LR|RL|BT)\b", text, re.I)
        if match:
            return "flowchart", match.group(2).upper(), position
        if re.match(r"^sequenceDiagram\b", text, re.I):
            return "sequenceDiagram", "LR", position
        if re.match(r"^stateDiagram(?:-v2)?(?![\w-])", text, re.I):
            return "stateDiagram-v2", "TD", position
        if re.match(r"^erDiagram\b", text, re.I):
            return "erDiagram", "TD", position
        token = text.split(maxsplit=1)[0]
        if token.casefold() in UNSUPPORTED_KINDS:
            _fail(
                f"unsupported diagram kind: `{token}` (supported: {SUPPORTED_KINDS})"
            )
        _fail(f"not a Mermaid file at line {line_number}")
    _fail("not a Mermaid file")


# Mermaid's flowchart lexer opens a string only at a double quote (a Markdown
# string is "`...`"), so an apostrophe is label text: `A[Bob's box]`,
# `A -->|it's| B`. Expanded `@{ ... }` attributes are YAML, where single
# quotes do delimit values (`label: '['`), so the scanners switch to the
# attribute quote set inside one. They count open `@{` entries alongside the
# bracket stack, so that test stays constant-time at any nesting depth.
FLOWCHART_QUOTES = "\"`"
ATTRIBUTE_QUOTES = "\"'`"
ATTRIBUTE_OPEN = "@{"


def _top_level_mask(text: str, quotes: str = FLOWCHART_QUOTES) -> str:
    """Keep top-level syntax positions and blank quoted/bracketed content."""
    output = list(text)
    stack: list[str] = []
    attributes = 0
    quote: str | None = None
    escaped = False
    pairs = {"]": "[", ")": "(", "}": "{"}
    for index, character in enumerate(text):
        if quote is not None:
            output[index] = " "
            if escaped:
                escaped = False
            elif character == "\\":
                escaped = True
            elif character == quote:
                quote = None
            continue
        if character in (ATTRIBUTE_QUOTES if attributes else quotes):
            quote = character
            output[index] = " "
            continue
        if character in "[({":
            if character == "{" and text[index - 1 : index] == "@":
                stack.append(ATTRIBUTE_OPEN)
                attributes += 1
            else:
                stack.append(character)
            output[index] = " "
            continue
        if character in "])}":
            if stack and stack[-1][-1] == pairs[character]:
                if stack.pop() == ATTRIBUTE_OPEN:
                    attributes -= 1
            output[index] = " "
            continue
        if stack:
            output[index] = " "
    return "".join(output)


def _split_top_level(
    text: str, delimiter: str, quotes: str = FLOWCHART_QUOTES
) -> list[str]:
    mask = _top_level_mask(text, quotes)
    parts: list[str] = []
    start = 0
    for index, character in enumerate(mask):
        if character == delimiter:
            parts.append(text[start:index])
            start = index + 1
    parts.append(text[start:])
    return parts


def _statement_complete(text: str) -> bool:
    """Return whether quotes and node delimiters close within a statement."""
    stack: list[str] = []
    attributes = 0
    quote: str | None = None
    escaped = False
    pairs = {"]": "[", ")": "(", "}": "{"}
    for index, character in enumerate(text):
        if quote is not None:
            if escaped:
                escaped = False
            elif character == "\\":
                escaped = True
            elif character == quote:
                quote = None
            continue
        if character in (ATTRIBUTE_QUOTES if attributes else FLOWCHART_QUOTES):
            quote = character
        elif character in "[({":
            if character == "{" and text[index - 1 : index] == "@":
                stack.append(ATTRIBUTE_OPEN)
                attributes += 1
            else:
                stack.append(character)
        elif character in "])}":
            if stack and stack[-1][-1] == pairs[character]:
                if stack.pop() == ATTRIBUTE_OPEN:
                    attributes -= 1
    return quote is None and not stack


def _statement_too_long(line_number: int) -> NoReturn:
    _fail(
        f"statement at line {line_number} exceeds the "
        f"{MAX_STATEMENT_CHARS}-character limit"
    )


def _logical_statements(
    lines: list[tuple[int, str]],
) -> list[tuple[int, str]]:
    """Join multiline Mermaid strings before parsing semicolon statements."""
    logical: list[tuple[int, str]] = []
    pending: list[str] = []
    start_line = 0
    for line_number, raw in lines:
        if not pending and not raw.strip():
            continue
        if not pending:
            start_line = line_number
        pending.append(raw)
        combined = "\n".join(pending)
        statements = _split_top_level(combined, ";")
        complete = _statement_complete(combined)
        # Everything before the last top-level semicolon is finished even while
        # a quote or bracket after it stays open, so only that open statement is
        # carried to the next line. Each statement is bounded on its own, and
        # the open one is bounded before the next line joins and rescans it.
        for statement in statements if complete else statements[:-1]:
            if len(statement) > MAX_STATEMENT_CHARS:
                _statement_too_long(start_line)
            logical.append((start_line, statement))
        if complete:
            pending = []
            continue
        if len(statements[-1]) > MAX_STATEMENT_CHARS:
            _statement_too_long(start_line)
        pending = [statements[-1]]
    if pending:
        _fail(f"unterminated statement at line {start_line}")
    return logical


SHAPE_FOR_DELIMITERS = (
    ("(((", ")))", "circle"),
    ("((", "))", "circle"),
    ("([", "])", "stadium"),
    ("{{", "}}", "hexagon"),
    ("[(", ")]", "cylinder"),
    ("[[", "]]", "subroutine"),
    ("[/", "/]", "parallelogram"),
    ("[\\", "\\]", "parallelogram"),
    ("[/", "\\]", "trapezoid"),
    ("[\\", "/]", "trapezoid"),
    ("[", "]", "rect"),
    ("(", ")", "round"),
    ("{", "}", "rhombus"),
    (">", "]", "asymmetric"),
)

EXPANDED_SHAPE_FAMILIES = {
    "rect": "rect",
    "rectangle": "rect",
    "proc": "rect",
    "process": "rect",
    "rounded": "round",
    "event": "round",
    "stadium": "stadium",
    "pill": "stadium",
    "terminal": "stadium",
    "circle": "circle",
    "circ": "circle",
    "sm-circ": "circle",
    "small-circle": "circle",
    "start": "circle",
    "dbl-circ": "circle",
    "double-circle": "circle",
    "fr-circ": "circle",
    "framed-circle": "circle",
    "stop": "circle",
    "cyl": "cylinder",
    "cylinder": "cylinder",
    "database": "cylinder",
    "db": "cylinder",
    "h-cyl": "cylinder",
    "horizontal-cylinder": "cylinder",
    "lin-cyl": "cylinder",
    "lined-cylinder": "cylinder",
    "diam": "rhombus",
    "decision": "rhombus",
    "diamond": "rhombus",
    "question": "rhombus",
    "hex": "hexagon",
    "hexagon": "hexagon",
    "prepare": "hexagon",
    "fr-rect": "subroutine",
    "framed-rectangle": "subroutine",
    "subproc": "subroutine",
    "subprocess": "subroutine",
    "subroutine": "subroutine",
    "lean-r": "parallelogram",
    "lean-l": "parallelogram",
    "in-out": "parallelogram",
    "lean-right": "parallelogram",
    "lean-left": "parallelogram",
    "out-in": "parallelogram",
    "trap-t": "trapezoid",
    "trap-b": "trapezoid",
    "trapezoid": "trapezoid",
    "inv-trapezoid": "trapezoid",
    "manual": "trapezoid",
    "priority": "trapezoid",
}


def classify_shape(expression: str) -> str:
    """Return the normalized Mermaid shape family for a node suffix."""
    for opening, closing, shape in SHAPE_FOR_DELIMITERS:
        if expression.startswith(opening) and expression.endswith(closing):
            return shape
    return "rect"


def _strip_class_suffix(text: str) -> str:
    """Drop Mermaid's `:::class` attachment; source styling is discarded."""
    mask = _top_level_mask(text)
    index = mask.find(":::")
    if index == -1:
        return text
    end = index + 3
    while end < len(text) and (text[end].isalnum() or text[end] in "_-"):
        end += 1
    return (text[:index] + text[end:]).strip()


def _parse_expanded_attributes(text: str) -> tuple[str, str] | None:
    """Normalize Mermaid v11.3+ ``@{ ... }`` node attributes.

    Only semantic label/shape data crosses the trust boundary. Image URLs,
    registered icon names, dimensions, and renderer configuration are dropped.
    """
    if not text.startswith("@{") or not text.endswith("}"):
        return None
    values: dict[str, str] = {}
    for raw_attribute in _split_top_level(text[2:-1], ",", ATTRIBUTE_QUOTES):
        key, separator, raw_value = raw_attribute.partition(":")
        if not separator:
            continue
        key = key.strip().casefold()
        if not re.fullmatch(r"[a-z][a-z0-9_-]*", key):
            continue
        values[key] = clean_label(raw_value)
    shape_name = values.get("shape", "").casefold()
    if not shape_name:
        if "img" in values:
            shape_name = "image"
        elif "icon" in values:
            shape_name = "icon"
        elif "shape" not in values:
            return values.get("label", ""), ""
        else:
            shape_name = "rect"
    if not re.fullmatch(r"[a-z][a-z0-9-]*", shape_name):
        shape_name = "rect"
    shape = EXPANDED_SHAPE_FAMILIES.get(shape_name, shape_name)
    return values.get("label", ""), shape


def _parse_node_expression(expression: str) -> tuple[str, str, str] | None:
    text = _strip_class_suffix(expression.strip().rstrip(";").strip())
    if not text:
        return None
    match = re.match(r"^([\w.:-]+)", text, re.UNICODE)
    if match is None:
        return None
    node_id = match.group(1)
    rest = text[match.end() :].strip()
    if not rest:
        return node_id, node_id, ""
    expanded = _parse_expanded_attributes(rest)
    if expanded is not None:
        label, shape = expanded
        return node_id, label or node_id, shape
    for opening, closing, _shape in SHAPE_FOR_DELIMITERS:
        if rest.startswith(opening) and rest.endswith(closing):
            label = rest[len(opening) : len(rest) - len(closing)]
            return node_id, clean_label(label), classify_shape(rest)
    return None


@dataclass
class _Operator:
    start: int
    end: int
    label: str
    style: str
    arrowhead: str
    bidirectional: bool = False
    undirected: bool = False


def _operator_style(token: str) -> tuple[str, str, bool, bool]:
    if token.startswith("~"):
        # `A ~~~ B` is an invisible link: it only places B near A.
        return "invisible", "none", False, True
    style = "dashed" if "." in token else "thick" if "=" in token else "solid"
    arrowhead = "cross" if token.endswith("x") else "circle" if token.endswith("o") else "arrow"
    undirected = ">" not in token and not token.endswith(("x", "o"))
    bidirectional = (
        token.startswith("<") and token.endswith(">")
    ) or (token.startswith(("x", "o")) and token.endswith(("x", "o")))
    return style, arrowhead, bidirectional, undirected


def _edge_operators(text: str) -> list[_Operator]:
    mask = _top_level_mask(text)
    operators: list[_Operator] = []
    occupied: list[tuple[int, int]] = []

    # Labeled links carry the label between the opening and closing operator:
    # `A-- text -->B`, `A-. retry .-> B`, `A== critical ==> B`, and the
    # undirected forms of each. The compact form drops the spaces —
    # `B--yes-->C` — and may retain a left arrow/circle/cross marker, as in
    # `A<--yes-->B` or `A o--yes--o B`. The spaced form consumes exactly one
    # whitespace character next to each operator; any further padding falls
    # inside the label span, which `clean_label` strips, so the operator
    # boundaries are never ambiguous.
    #
    # A compact dash or equals label may contain whitespace, including the
    # blanks the mask writes over brackets, so `A==a b==>B` and `A--f(x)-->B`
    # stay one labeled link. `-`, `=`, `.`, or `>` immediately after the
    # opening still continues an unlabeled operator (`A----->B`). Mermaid's
    # lexer always reads `x` or `o` immediately after `--` or `==` as that
    # link's arrowhead, so a compact label cannot start with either letter:
    # `A--x marks-->B`, `A--x marks -->B`, and `A--orders-->B` are two links
    # through a `marks` or `rders` node, like `A --o B --> C`. Mermaid
    # rejects `A--x(a)-->B` outright. A spaced label (`A-- x marks -->B`)
    # is unaffected. The dotted form's closing operator always opens with a
    # literal `.`, so its compact label may contain internal whitespace and
    # start with `x` or `o` (as in `A-.x y.->B`). An opening never starts
    # inside a longer operator, so `A --- B-->C` stays two links.
    text_edge = re.compile(
        r"(?P<opening>"
        r"<(?:--|==)"
        r"|(?<![\w.:-])[xo](?:--|==)"
        r"|(?<![-=])(?:--|==)"
        r")"
        r"(?![-=.>xo])"
        r"(?:\s(?P<spaced>.+?)\s|(?P<compact>[^|<>]+?))"
        r"(?P<closing>-{2,}>|--[xo]|=+>|={2,}|-{3,})"
    )
    dotted_edge = re.compile(
        r"(?P<opening>"
        r"<-\."
        r"|(?<![\w.:-])[xo]-\."
        r"|-\."
        r")"
        r"(?:\s(?P<spaced>.+?)\s|(?![-=.\s])(?P<compact>[^\n|<>]+?))"
        r"(?P<closing>\.-+[>xo]|\.-+)"
    )
    trailing_operator = re.compile(
        r"(?:\.-+[>xo]|\.-+|-{2,}>|--[xo]|=+>|={2,}|-{3,}|~{3,})"
        r"(?:\|[^|\n]*\|)?\s*$"
    )
    for edge_pattern in (text_edge, dotted_edge):
        for match in edge_pattern.finditer(mask):
            opening = match.group("opening")
            operator_start = match.start()
            if opening.startswith(("x", "o")):
                prefix = mask[:operator_start]
                if not prefix.strip() or trailing_operator.search(prefix):
                    # Here x/o is the endpoint before a regular opening
                    # operator, not a left marker: `x--yes-->B` or
                    # `A-->x--go-->B`.
                    operator_start += 1
                    opening = opening[1:]
            token = opening + match.group("closing")
            style, arrowhead, bidirectional, undirected = _operator_style(token)
            # Read the label from the whole span between the operators rather
            # than from the matched group. The mask blanks quoted spans, so a
            # quoted label — `A-- "text" -->B` — leaves the spaced group
            # nothing but blanks to settle on, and slicing that group returns
            # a stray quote instead of the text. `clean_label` strips the
            # padding and quotes.
            operators.append(
                _Operator(
                    operator_start,
                    match.end(),
                    clean_label(text[match.end("opening") : match.start("closing")]),
                    style,
                    arrowhead,
                    bidirectional,
                    undirected,
                )
            )
            occupied.append((operator_start, match.end()))

    # A dotted link grows by dots: `-.->`, `-..->`, `-...->` and `-.-`, `-..-`.
    # A single dash before x/o belongs to a node id such as `node-x`.
    pattern = re.compile(
        r"[xo][-=.]{2,}[xo]|<[-=.]+>|-+\.+-+>|=+>|-+>|-{2,}[xo]|={2,}[xo]|-+\.+-+|={3,}|-{3,}|~{3,}"
    )
    for match in pattern.finditer(mask):
        # Overlap, not just a contained start. An unlabeled token can begin
        # before a labeled operator and end inside it — `Ao-.x y.->B` offers
        # `o-.x` to `[xo][-=.]{2,}[xo]`, one character ahead of the `-.x y.->`
        # span already claimed above. Keeping both cuts the line into
        # segments that no longer reconstruct it.
        if any(match.start() < end and start < match.end() for start, end in occupied):
            continue
        token = match.group()
        end = match.end()
        label = ""
        # Mermaid allows whitespace between the link and its pipe label:
        # `A --> |yes| B` reads the same as `A -->|yes| B`.
        opening_pipe = end
        while opening_pipe < len(text) and text[opening_pipe] in " \t":
            opening_pipe += 1
        if opening_pipe < len(text) and text[opening_pipe] == "|":
            close = text.find("|", opening_pipe + 1)
            if close != -1:
                label = clean_label(text[opening_pipe + 1 : close])
                end = close + 1
        style, arrowhead, bidirectional, undirected = _operator_style(token)
        operators.append(
            _Operator(
                match.start(), end, label, style, arrowhead, bidirectional, undirected
            )
        )
        occupied.append((match.start(), end))
    return sorted(operators, key=lambda operator: operator.start)


def _endpoint_group(
    diagram: Diagram, text: str, parent: str | None
) -> list[str] | None:
    identifiers: list[str] = []
    for raw in _split_top_level(text.strip(), "&"):
        parsed = _parse_node_expression(raw)
        if parsed is None:
            return None
        node_id, label, shape = parsed
        # A link token outside any shape means a link that did not parse.
        if shape != "asymmetric" and re.search(r"--|==|-\.|\s[-=][xo]", _top_level_mask(raw)):
            return None
        diagram.add_node(node_id, label, shape, parent)
        identifiers.append(node_id)
    return identifiers or None


STYLE_DIRECTIVES = ("style ", "classDef ", "class ", "linkStyle ")


_EDGE_ID = re.compile(r"(?<![\w.:@-])([A-Za-z_][\w-]*)@")


def _strip_edge_ids(text: str) -> tuple[str, list[str]]:
    """Drop Mermaid v11.6+ edge IDs (`A e1@--> B`) and return the IDs found."""
    mask = _top_level_mask(text)
    operator_starts = {operator.start for operator in _edge_operators(text)}
    ids: list[str] = []
    pieces: list[str] = []
    cursor = 0
    for match in _EDGE_ID.finditer(mask):
        if match.end() not in operator_starts:
            continue
        pieces.append(text[cursor : match.start()])
        cursor = match.end()
        ids.append(match.group(1))
    if not ids:
        return text, ids
    pieces.append(text[cursor:])
    return "".join(pieces), ids


def _discard_nonsemantic(diagram: Diagram, text: str) -> bool:
    lowered = text.casefold()
    if any(lowered.startswith(prefix.casefold()) for prefix in STYLE_DIRECTIVES):
        diagram.discarded["style_directives"] += 1
        return True
    if lowered.startswith("click "):
        diagram.discarded["click_handlers"] += 1
        return True
    return False


def _parse_flowchart(
    diagram: Diagram, lines: list[tuple[int, str]], header_position: int
) -> None:
    containers: list[str] = []
    invisible_links = 0
    edge_ids: set[str] = set()
    for line_number, raw in _logical_statements(lines[header_position + 1 :]):
        text = raw.strip()
        if not text:
            continue
        lowered = text.casefold()
        if _discard_nonsemantic(diagram, text):
            continue
        id_match = re.match(r"^([A-Za-z_][\w-]*)@\{", text)
        if id_match and id_match.group(1) in edge_ids:
            # `e1@{ animate: true }` styles an edge, not a node.
            continue
        if lowered.startswith("direction "):
            if not containers:
                direction = text.split(maxsplit=1)[1].upper()
                if direction in {"TD", "TB", "LR", "RL", "BT"}:
                    diagram.direction = direction
            continue
        if lowered.startswith("subgraph "):
            spec = text.split(maxsplit=1)[1].strip()
            parsed = _parse_node_expression(spec)
            if parsed is None:
                generated = f"subgraph-{len([node for node in diagram.nodes if node.container]) + 1}"
                node_id, label = generated, clean_label(spec)
            else:
                node_id, label, _shape = parsed
            parent = containers[-1] if containers else None
            diagram.add_node(node_id, label, "container", parent, container=True)
            containers.append(node_id)
            continue
        if lowered == "end":
            if containers:
                containers.pop()
            continue

        text, found_ids = _strip_edge_ids(text)
        edge_ids.update(found_ids)
        operators = _edge_operators(text)
        parent = containers[-1] if containers else None
        if operators:
            segments: list[str] = []
            cursor = 0
            for operator in operators:
                segments.append(text[cursor : operator.start])
                cursor = operator.end
            segments.append(text[cursor:])
            if len(segments) != len(operators) + 1:
                _fail(f"malformed edge at line {line_number}")
            groups = [_endpoint_group(diagram, segment, parent) for segment in segments]
            if any(group is None for group in groups):
                _fail(f"malformed edge at line {line_number}")
            valid_groups = [group for group in groups if group is not None]
            for index, operator in enumerate(operators):
                if operator.style == "invisible":
                    # The endpoints were declared above; the link itself is a
                    # layout hint with no meaning of its own.
                    invisible_links += 1
                    continue
                for source in valid_groups[index]:
                    for target in valid_groups[index + 1]:
                        diagram.add_edge(
                            source,
                            target,
                            operator.label,
                            operator.style,
                            operator.arrowhead,
                            operator.bidirectional,
                            operator.undirected,
                        )
            continue
        parsed = _parse_node_expression(text)
        # The mask blanks shaped labels, so a link token left in it sits
        # outside any shape. The asymmetric `>` opener is not masked.
        masked = _top_level_mask(text)
        malformed_link = re.search(
            r"(?:--|==|-\.).*?(?:>|x|o|-)|\s[-=][xo]",
            masked,
        )
        bare_link_start = re.search(r"--|==|-\.", masked)
        if parsed is not None and not (
            parsed[2] != "asymmetric" and (malformed_link or bare_link_start)
        ):
            node_id, label, shape = parsed
            diagram.add_node(node_id, label, shape, parent)
            continue
        if (
            malformed_link
            or bare_link_start
            # Not a node but link-like (`A- >B`): fail instead of dropping it.
            # The dot matches any character on purpose.
            or (parsed is None and re.search(r"(?:==|-.).*?(?:>|x|o|-)", masked))
        ):
            _fail(f"malformed edge at line {line_number}")
    if invisible_links:
        diagram.notes.append(f"{invisible_links} invisible layout links ignored")


def _parse_sequence(
    diagram: Diagram, lines: list[tuple[int, str]], header_position: int
) -> None:
    # None marks a visual-only rect block: its end must not close a semantic fragment.
    fragment_stack: list[dict[str, Any] | None] = []
    semantic_depth = 0
    participant_re = re.compile(
        r"^(?:create\s+)?(participant|actor)\s+"
        r"(?:\"([^\"]+)\"|'([^']+)'|([\w.:-]+))"
        r"(?:\s+as\s+(.+))?$",
        re.I,
    )
    # Endpoints may be bare ids or multi-word names introduced by a quoted
    # `participant "Alice Smith"` declaration; the lazy id keeps `A-->>B`
    # from swallowing dashes into the source.
    message_re = re.compile(
        r"^([\w.:-]+?(?: [\w.:-]+)*?)(?:\(\))?\s*"
        r"(<<--?>>|--?>>|--?>|--?\)|--?x)"
        r"\s*[+-]?\s*(?:\(\))?([\w.:-]+?(?: [\w.:-]+)*?)\s*:\s*(.*)$"
    )
    for line_number, raw in lines[header_position + 1 :]:
        text = raw.strip()
        if not text:
            continue
        lowered = text.casefold()
        if _discard_nonsemantic(diagram, text):
            continue
        participant = participant_re.match(text)
        if participant:
            kind = participant.group(1).casefold()
            quoted = participant.group(2) or participant.group(3)
            bare = participant.group(4)
            alias = participant.group(5)
            if quoted is not None:
                # `participant "Alice Smith" as A` — messages use the alias,
                # the quoted string is the display name.
                node_id = alias or quoted
                label = quoted
            else:
                # `participant A as Alice` — the bare token is the id.
                node_id = bare
                label = alias or bare
            diagram.add_node(
                node_id,
                clean_label(label),
                "actor" if kind == "actor" else "lifeline",
            )
            continue
        if (re.match(r"^rect\s+", text, re.I) and message_re.match(text) is None
                and re.match(r"^rect\s+(?:<<--?>>|--?>>|--?>|--?\)|--?x)", text, re.I) is None):
            fragment_stack.append(None)
            continue
        fragment = re.match(r"^(alt|opt|loop|par|critical|break)\b\s*(.*)$", text, re.I)
        if fragment:
            entry = {
                "kind": fragment.group(1).casefold(),
                "label": clean_label(fragment.group(2)),
                "line": line_number,
                "depth": semantic_depth,
                "regions": [],
            }
            diagram.fragments.append(entry)
            fragment_stack.append(entry)
            semantic_depth += 1
            continue
        region = re.match(r"^(else|and|option)\b\s*(.*)$", text, re.I)
        if region and fragment_stack and fragment_stack[-1] is not None:
            fragment_stack[-1]["regions"].append(clean_label(region.group(2)))
            continue
        if lowered == "end":
            if fragment_stack and fragment_stack.pop() is not None:
                semantic_depth -= 1
            continue
        if lowered.startswith(("activate ", "deactivate ", "+", "-")):
            continue
        numbering = re.match(r"^autonumber(?:\s+(off)|\s+(\d+)(?:\s+(\d+))?)?$", text, re.I)
        if numbering:
            off, start, step = numbering.groups()
            entry = {"line": line_number, "off": bool(off)}
            if not off:
                if any(len(value or "") > MAX_AUTONUMBER_DIGITS for value in (start, step)):
                    _fail(
                        f"autonumber value exceeds {MAX_AUTONUMBER_DIGITS} digits "
                        f"at line {line_number}"
                    )
                entry.update(start=int(start or 1), step=int(step or 1))
            diagram.autonumber.append(entry)
            continue
        if lowered.startswith("note "):
            _, separator, note = text.partition(":")
            diagram.notes.append(clean_label(note if separator else text[5:]))
            continue
        message = message_re.match(text)
        if message:
            source, token, target, label = message.groups()
            # Auto-add endpoints only when undeclared, so an earlier
            # `actor`/`participant` declaration keeps its shape and label.
            for endpoint in (source, target):
                if endpoint not in diagram.node_map:
                    diagram.add_node(endpoint, endpoint, "lifeline")
            if token.endswith("x"):
                arrowhead = "cross"
            elif token.endswith(")"):
                arrowhead = "async"
            elif token.endswith(">>"):
                arrowhead = "arrow"
            else:  # `->` / `-->` are open arrows with no arrowhead
                arrowhead = "none"
            diagram.add_edge(
                source,
                target,
                clean_label(label),
                "dashed"
                if token.startswith("--") or token.startswith("<<--")
                else "solid",
                arrowhead,
                bidirectional=token.startswith("<<"),
                undirected=arrowhead == "none",
            )
            continue
        if re.search(r"<<--?>>|--?>>|--?>|--?\)|--?x", text):
            _fail(f"malformed edge at line {line_number}")


def _state_endpoint(
    diagram: Diagram,
    token: str,
    role: str,
    parent: str | None,
) -> str | None:
    value = _strip_class_suffix(token.strip())
    if value == "[*]":
        prefix = "start" if role == "source" else "end"
        count = sum(node.id.startswith("__" + prefix) for node in diagram.nodes)
        node_id = f"__{prefix}_{count + 1}"
        diagram.add_node(node_id, f"[{prefix}]", prefix, parent)
        return node_id
    parsed = _parse_node_expression(value)
    if parsed is None:
        return None
    node_id, label, shape = parsed
    if not shape:
        existing = diagram.node_map.get(node_id)
        shape = existing.shape if existing is not None else "state"
    elif shape == "rect":
        shape = "state"
    diagram.add_node(node_id, label, shape, parent)
    return node_id


def _parse_state(
    diagram: Diagram, lines: list[tuple[int, str]], header_position: int
) -> None:
    containers: list[str] = []
    note_start: int | None = None
    descriptions: dict[str, list[str]] = {}
    pending_descriptions = diagram._state_descriptions
    for line_number, raw in lines[header_position + 1 :]:
        text = raw.strip()
        if not text:
            continue
        if note_start is not None:
            if re.fullmatch(r"end\s+note", text, re.I):
                note_start = None
            continue
        note = re.fullmatch(
            r"note\s+(?:left|right)\s+of\s+[^\s:]+(?:\s*:\s*(.*))?", text, re.I
        )
        if note:
            # A colon marks a single-line note; otherwise ignore its opaque body
            # through `end note` before interpreting states, edges or braces.
            if note.group(1) is None:
                note_start = line_number
            else:
                diagram.notes.append(clean_label(note.group(1)))
            continue
        if _discard_nonsemantic(diagram, text):
            continue
        if text == "}":
            if containers:
                containers.pop()
            continue
        parent = containers[-1] if containers else None
        direction_match = re.match(r"^direction\s+(TD|TB|LR|RL|BT)$", text, re.I)
        if direction_match and not containers:
            diagram.direction = direction_match.group(1).upper()
            continue
        composite = re.match(r"^state\s+([\w.:-]+)\s*\{$", text, re.I)
        if composite:
            node_id = composite.group(1)
            diagram.add_node(node_id, node_id, "container", parent, container=True)
            containers.append(node_id)
            continue
        alias = re.match(r'^state\s+"(.*?)"\s+as\s+([\w.:-]+)\s*(\{)?$', text, re.I)
        if alias:
            label, node_id, opening = alias.groups()
            diagram.add_node(node_id, clean_label(label), "container" if opening else "state", parent, container=bool(opening))
            # A renaming alias discards earlier descriptions; later ones build on it.
            if node_id not in pending_descriptions:
                descriptions.pop(node_id, None)
            if opening:
                containers.append(node_id)
            continue
        stereotype = re.match(
            r"^state\s+([\w.:-]+)\s+<<(fork|join|choice)>>$", text, re.I
        )
        if stereotype:
            diagram.add_node(
                stereotype.group(1), stereotype.group(1), stereotype.group(2).casefold(), parent
            )
            continue
        if "-->" in text:
            source_text, target_text = text.split("-->", 1)
            label = ""
            label_separator = re.search(r"(?<!:):(?!:)", target_text)
            if label_separator:
                label = target_text[label_separator.end() :]
                target_text = target_text[: label_separator.start()]
            source = _state_endpoint(diagram, source_text, "source", parent)
            target = _state_endpoint(diagram, target_text, "target", parent)
            if source is None or target is None:
                _fail(f"malformed edge at line {line_number}")
            diagram.add_edge(source, target, clean_label(label))
            continue
        description = re.match(r"^([\w.-]+)\s*:\s*(.+)$", text)
        if description:
            node_id, label = description.group(1), clean_label(description.group(2))
            if node_id not in descriptions:
                existing = diagram.node_map.get(node_id)
                descriptions[node_id] = [existing.label] if existing and existing.label != node_id else []
            descriptions[node_id].append(label)
            diagram.add_node(node_id, label, "state", parent)
            pending_descriptions[node_id] = descriptions[node_id]
            continue
        plain = re.match(r"^state\s+([\w.:-]+)$", text, re.I)
        if plain:
            diagram.add_node(plain.group(1), plain.group(1), "state", parent)
            continue
        if text != "--" and re.fullmatch(r"[\w.:-]+", text):
            if text not in diagram.node_map:
                diagram.add_node(text, text, "state", parent)

    if note_start is not None:
        _fail(f"unterminated state note at line {note_start}")

    # Materialize each accumulated label once; later explicit aliases still win.
    for node_id, parts in pending_descriptions.items():
        label = "\n".join(parts)
        if label:
            diagram.node_map[node_id].label = label
    pending_descriptions.clear()


def _parse_er(
    diagram: Diagram, lines: list[tuple[int, str]], header_position: int
) -> None:
    current: Node | None = None
    aliased_names: set[str] = set()
    relationship = re.compile(
        rf"^({ER_NAME})\s+"
        rf"(?i:({ER_CARDINALITY})\s*({ER_IDENTIFICATION})\s*({ER_CARDINALITY}))\s+"
        rf"({ER_NAME})\s*(?::\s*(.*))?$"
    )
    # `p[Person]` shows the alias in place of the entity name. Relationships
    # use the name, so an alias is valid only on a declaration.
    declaration = re.compile(rf"^({ER_NAME})(?:\s*\[({ER_NAME})\])?\s*(\{{)?$")
    for line_number, raw in lines[header_position + 1 :]:
        text = raw.strip()
        if not text:
            continue
        if _discard_nonsemantic(diagram, text):
            continue
        if text == "}":
            current = None
            continue
        direction_match = re.match(r"^direction\s+(TD|TB|LR|RL|BT)$", text, re.I)
        if direction_match and current is None:
            diagram.direction = direction_match.group(1).upper()
            continue
        declared = _er_declaration(declaration.match(text))
        if declared is not None and declared[3]:
            current = _er_table(diagram, aliased_names, *declared[:3])
            continue
        if current is not None:
            current.fields.append(clean_label(text))
            continue
        edge = relationship.match(text)
        if edge and _er_entity(edge.group(1)) and _er_entity(edge.group(5)):
            source_token, left, link, right, target_token, relationship_label = edge.groups()
            source = _er_table(diagram, aliased_names, _er_entity(source_token), _er_label(source_token)).id
            target = _er_table(diagram, aliased_names, _er_entity(target_token), _er_label(target_token)).id
            separator = ER_IDENTIFICATIONS[link.casefold()]
            left = ER_CARDINALITIES[left.casefold()][0]
            right = ER_CARDINALITIES[right.casefold()][1]
            label_parts = [f"{left} {separator} {right}"]
            if relationship_label:
                label_parts.append(clean_label(relationship_label))
            diagram.add_edge(
                source,
                target,
                " · ".join(label_parts),
                "dashed" if separator == ".." else "solid",
                "cardinality",
                undirected=True,
            )
            continue
        # A quoted name may contain `--` or `..` as plain text.
        unquoted = re.sub(ER_QUOTED_NAME, '""', text)
        if "--" in unquoted or ".." in unquoted:
            _fail(f"malformed edge at line {line_number}")
        if declared is not None:
            _er_table(diagram, aliased_names, *declared[:3])


def _er_label(token: str) -> str:
    """Return the display text of an ER name token."""
    return clean_label(token) if token.startswith('"') else token


def _er_declaration(
    match: re.Match[str] | None,
) -> tuple[str, str, bool, bool] | None:
    """Return (name, label, aliased, opens_block) for an ER entity declaration."""
    if match is None:
        return None
    name_token, alias_token, block = match.groups()
    name = _er_entity(name_token)
    if name is None:
        return None
    if alias_token is None:
        return name, _er_label(name_token), False, block is not None
    if _er_entity(alias_token) is None:
        return None
    return name, _er_label(alias_token), True, block is not None


def _er_table(
    diagram: Diagram,
    aliased_names: set[str],
    name: str,
    label: str,
    aliased: bool = False,
) -> Node:
    """Add an ER table. As in Mermaid, only an entity's first alias sets its label."""
    existing = diagram.node_map.get(name)
    if aliased and name not in aliased_names:
        aliased_names.add(name)
        if existing is not None:
            existing.label = label
            return existing
    elif existing is not None:
        return existing
    return diagram.add_node(name, label, "table")


def parse_block(block: SourceBlock) -> Diagram:
    lines, config_directives = _prepared_lines(block)
    kind, direction, header_position = _kind_and_direction(lines)
    if kind == "flowchart":
        # `graph TD; A-->B;` is valid: statements may follow the header's
        # semicolon on the same line, so keep them as the first statement.
        line_number, header = lines[header_position]
        rest = re.match(r"^\s*(?:flowchart|graph)\s+(?:TD|TB|LR|RL|BT)\b", header, re.I)
        tail = header[rest.end() :].lstrip() if rest else ""
        if tail.startswith(";"):
            lines[header_position] = (line_number, header[: rest.end()])
            lines.insert(header_position + 1, (line_number, tail[1:]))
    diagram = Diagram(block.index, kind, block.source_line, direction=direction)
    diagram.discarded["config_directives"] = config_directives
    if kind == "flowchart":
        _parse_flowchart(diagram, lines, header_position)
    elif kind == "sequenceDiagram":
        _parse_sequence(diagram, lines, header_position)
    elif kind == "stateDiagram-v2":
        _parse_state(diagram, lines, header_position)
    else:
        _parse_er(diagram, lines, header_position)
    _finalize_degrees(diagram)
    return diagram


def _finalize_degrees(diagram: Diagram) -> None:
    nodes = diagram.node_map
    for edge in diagram.edges:
        if edge.source in nodes:
            nodes[edge.source].out_degree += 1
        if edge.target in nodes:
            nodes[edge.target].in_degree += 1
        if edge.bidirectional:
            if edge.source in nodes:
                nodes[edge.source].in_degree += 1
            if edge.target in nodes:
                nodes[edge.target].out_degree += 1


def _has_cycle(nodes: list[Node], edges: list[Edge]) -> bool:
    adjacency: dict[str, list[str]] = {node.id: [] for node in nodes}
    for edge in edges:
        if edge.source in adjacency and edge.target in adjacency:
            adjacency[edge.source].append(edge.target)
            if edge.bidirectional:
                adjacency[edge.target].append(edge.source)
    WHITE, GREY, BLACK = 0, 1, 2
    colors = {node.id: WHITE for node in nodes}

    def visit(start: str) -> bool:
        stack: list[tuple[str, Any]] = [(start, iter(adjacency[start]))]
        colors[start] = GREY
        while stack:
            node_id, targets = stack[-1]
            for target in targets:
                if colors.get(target, BLACK) == GREY:
                    return True
                if colors.get(target, BLACK) == WHITE:
                    colors[target] = GREY
                    stack.append((target, iter(adjacency.get(target, []))))
                    break
            else:
                colors[node_id] = BLACK
                stack.pop()
        return False

    return any(colors[node.id] == WHITE and visit(node.id) for node in nodes)


def shape_family(shape: str) -> str:
    return "container" if shape == "container" else shape


def analyze(diagram: Diagram) -> dict[str, Any]:
    containers = [node for node in diagram.nodes if node.container or node.children]
    leaves = [node for node in diagram.nodes if not (node.container or node.children)]
    shapes: dict[str, int] = {}
    for node in diagram.nodes:
        family = shape_family(node.shape)
        shapes[family] = shapes.get(family, 0) + 1

    def name(node: Node) -> str:
        return node.label.replace("\n", " · ") or node.id

    hubs = [
        {"id": node.id, "label": name(node), "degree": node.in_degree + node.out_degree}
        for node in sorted(
            leaves,
            key=lambda item: (item.in_degree + item.out_degree, item.id),
            reverse=True,
        )[:5]
        if node.in_degree + node.out_degree > 0
    ]
    entry_points = [name(node) for node in leaves if node.out_degree and not node.in_degree]
    terminals = [name(node) for node in leaves if node.in_degree and not node.out_degree]
    orphans = [name(node) for node in leaves if not node.in_degree and not node.out_degree]
    candidates = {
        "flowchart": ["flowchart" if shapes.get("rhombus") else "architecture", "architecture"],
        "sequenceDiagram": ["sequence"],
        "stateDiagram-v2": ["state machine"],
        "erDiagram": ["ER / data model"],
    }[diagram.kind]
    candidates = list(dict.fromkeys(candidates))
    collapsible = [
        {
            "id": node.id,
            "label": name(node),
            "children": len(node.children),
            "child_labels": [
                name(diagram.node_map[child])
                for child in node.children
                if child in diagram.node_map
            ][:8],
        }
        for node in containers
        if node.children
    ]
    collapsible.sort(key=lambda item: item["children"], reverse=True)
    drawable = len(leaves)
    return {
        "nodes_total": len(diagram.nodes),
        "nodes_drawable": drawable,
        "containers": len(containers),
        "leaves": len(leaves),
        "edges_total": len(diagram.edges),
        "edges_labeled": sum(bool(edge.label) for edge in diagram.edges),
        "edges_dangling": 0,
        "max_depth": max((node.depth for node in diagram.nodes), default=0),
        "shapes": dict(sorted(shapes.items(), key=lambda item: (-item[1], item[0]))),
        "has_cycle": _has_cycle(diagram.nodes, diagram.edges),
        "hubs": hubs,
        "entry_points": entry_points[:6],
        "terminals": terminals[:6],
        "orphans": orphans[:6],
        "type_candidates": candidates,
        "collapsible_groups": collapsible[:8],
        "over_node_budget": drawable > 9,
        "over_edge_budget": len(diagram.edges) > 12,
    }


def _escape_markdown(text: str) -> str:
    encoded = html.escape(text, quote=False)
    return re.sub(r"([\\`*{}\[\]()#+\-.!_|>])", r"\\\1", encoded)


def _escape_table(text: str) -> str:
    return _escape_markdown(text.replace("\n", " ⏎ "))


def _block_summary(block: SourceBlock, selected: list[Diagram]) -> str:
    """One header entry. A block that was not selected is parsed only to
    describe it, so a failure there is listed instead of ending the run."""
    diagram = next((item for item in selected if item.index == block.index), None)
    if diagram is None:
        try:
            diagram = parse_block(block)
        except ExtractError as error:
            return f"[{block.index}] unparsed: {_escape_markdown(str(error))}"
    return f"[{diagram.index}] {diagram.kind} ({len(diagram.nodes)}n/{len(diagram.edges)}e)"


# The keyword that opens each extra region of a fragment: `else` in alt, `and` in par, `option` in critical.
REGION_KEYWORDS = {"alt": "else", "par": "and", "critical": "option"}


def _fragment_digest(item: dict[str, Any]) -> str:
    keyword = REGION_KEYWORDS.get(item["kind"], "else")
    parts = [item["label"] or "unlabeled"] + [f"{keyword}: {region or 'unlabeled'}" for region in item["regions"]]
    return " | ".join(_escape_table(part) for part in parts)


def digest(
    path: Path,
    blocks: list[SourceBlock],
    selected: list[Diagram],
    max_rows: int,
) -> str:
    output = [f"# Mermaid IR — {path.name}", ""]
    output.append(
        f"{len(blocks)} diagram(s): "
        + ", ".join(_block_summary(block, selected) for block in blocks)
    )
    for diagram in selected:
        info = analyze(diagram)
        output.extend(
            [
                "",
                f"## Diagram {diagram.index} — {diagram.kind}",
                "",
                f"- source layout: none (Mermaid is layout-free); direction: {diagram.direction}",
                f"- nodes: {info['nodes_total']} total / {info['nodes_drawable']} drawable / "
                f"{info['containers']} containers, depth {info['max_depth']}",
                f"- edges: {info['edges_total']} ({info['edges_labeled']} labeled, "
                f"{info['edges_dangling']} dangling), cycle: {info['has_cycle']}",
                f"- shapes: {info['shapes']}",
                f"- type candidates: {', '.join(info['type_candidates'])}",
                f"- budget: nodes {'OVER' if info['over_node_budget'] else 'ok'} (max 9), "
                f"edges {'OVER' if info['over_edge_budget'] else 'ok'} (max 12)",
            ]
        )
        if any(diagram.discarded.values()):
            output.append(
                f"- discarded: {diagram.discarded['style_directives']} style directives, "
                f"{diagram.discarded['click_handlers']} click handlers, "
                f"{diagram.discarded['config_directives']} config directives"
            )
        if diagram.fragments:
            fragments = ", ".join(
                f"{item['kind']}({_fragment_digest(item)})" for item in diagram.fragments
            )
            output.append(f"- fragments: {fragments}")
        if diagram.autonumber:
            numbering = "; ".join(
                "off" if item["off"] else f"from {item['start']}, step {item['step']}"
                for item in diagram.autonumber
            )
            output.append(f"- autonumber: {numbering}")
        if diagram.notes:
            output.append(
                f"- notes: {'; '.join(_escape_markdown(note) for note in diagram.notes[:6])}"
            )
        if info["hubs"]:
            output.append(
                "- hubs (focal candidates): "
                + ", ".join(
                    f"{_escape_markdown(hub['label'])}({hub['degree']})"
                    for hub in info["hubs"]
                )
            )
        if info["entry_points"]:
            output.append(
                f"- entry points: {', '.join(_escape_markdown(label) for label in info['entry_points'])}"
            )
        if info["terminals"]:
            output.append(
                f"- terminals: {', '.join(_escape_markdown(label) for label in info['terminals'])}"
            )
        if info["orphans"]:
            output.append(
                f"- unconnected: {', '.join(_escape_markdown(label) for label in info['orphans'])}"
            )
        if info["collapsible_groups"]:
            output.append("- collapsible groups (simplify here first):")
            for group in info["collapsible_groups"]:
                output.append(
                    f"  - {_escape_markdown(group['label'])} — {group['children']} children: "
                    + ", ".join(_escape_markdown(label) for label in group["child_labels"])
                )

        output.extend(
            [
                "",
                "### Nodes",
                "",
                "| id | label | shape | depth | parent | deg | fields |",
                "|---|---|---|---|---|---|---|",
            ]
        )
        for node in diagram.nodes[:max_rows]:
            output.append(
                f"| {_escape_table(node.id)} | {_escape_table(node.label)} | {node.shape} | "
                f"{node.depth} | {node.parent or '-'} | {node.in_degree}/{node.out_degree} | "
                f"{_escape_table('; '.join(node.fields)) or '-'} |"
            )
        if len(diagram.nodes) > max_rows:
            output.append(
                f"| … | +{len(diagram.nodes) - max_rows} more (use --json) | | | | | |"
            )

        output.extend(
            [
                "",
                "### Edges",
                "",
                "| source | target | label | style |",
                "|---|---|---|---|",
            ]
        )
        names = {node.id: node.label.split("\n")[0] for node in diagram.nodes}
        for edge in diagram.edges[:max_rows]:
            marks = [edge.style, edge.arrowhead]
            if edge.bidirectional:
                marks.append("bidir")
            if edge.undirected:
                marks.append("undirected")
            output.append(
                f"| {_escape_table(names.get(edge.source, edge.source))} | "
                f"{_escape_table(names.get(edge.target, edge.target))} | "
                f"{_escape_table(edge.label) or '-'} | {' '.join(marks)} |"
            )
        if len(diagram.edges) > max_rows:
            output.append(
                f"| … | +{len(diagram.edges) - max_rows} more (use --json) | | |"
            )
    output.append("")
    return "\n".join(output)


def to_json(path: Path, blocks: list[SourceBlock], selected: list[Diagram]) -> str:
    return json.dumps(
        {
            "source": str(path),
            "diagrams_total": len(blocks),
            "diagrams": [
                {
                    "index": diagram.index,
                    "kind": diagram.kind,
                    "source_line": diagram.source_line,
                    "direction": diagram.direction,
                    "analysis": analyze(diagram),
                    "discarded": diagram.discarded,
                    "fragments": diagram.fragments,
                    "notes": diagram.notes,
                    "autonumber": diagram.autonumber,
                    "nodes": [asdict(node) for node in diagram.nodes],
                    "edges": [asdict(edge) for edge in diagram.edges],
                }
                for diagram in selected
            ],
        },
        indent=2,
        ensure_ascii=False,
    )


def select_blocks(blocks: list[SourceBlock], selector: str | None) -> list[SourceBlock]:
    """Pick blocks before parsing, so a bad block fails only when selected."""
    if selector is None:
        return blocks[:1]
    if selector == "all":
        return blocks
    if selector.isdecimal():
        index = int(selector)
        selected = [block for block in blocks if block.index == index]
        if not selected:
            _fail(f"no diagram with index {index} (have 0..{len(blocks) - 1})")
        return selected
    _fail("--diagram must be an index or 'all'")


def main(argv: list[str] | None = None) -> int:
    try:
        return _run(argv)
    except ExtractError as error:
        print(f"mermaid_extract: {error}", file=sys.stderr)
        raise SystemExit(2) from None


def _run(argv: list[str] | None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    parser.add_argument("file", help=".mmd, .mermaid, or Markdown with mermaid fences")
    parser.add_argument(
        "--diagram", help="diagram index or 'all' (default: first diagram)"
    )
    parser.add_argument("--json", action="store_true", help="emit the full IR as JSON")
    parser.add_argument(
        "--max-rows",
        type=int,
        default=40,
        help="rows per table in the Markdown digest (default 40)",
    )
    parser.add_argument("--out", help="write to this path instead of stdout")
    args = parser.parse_args(argv)
    if args.max_rows < 1:
        _fail("--max-rows must be at least 1")

    path = Path(args.file)
    if not path.is_file():
        _fail(f"{path}: no such file")
    blocks = load_blocks(path)
    selected = [parse_block(block) for block in select_blocks(blocks, args.diagram)]
    output = (
        to_json(path, blocks, selected)
        if args.json
        else digest(path, blocks, selected, args.max_rows)
    )
    if args.out:
        try:
            Path(args.out).write_text(output, encoding="utf-8")
        except OSError as error:
            _fail(f"cannot write {args.out}: {error}")
        print(f"wrote {args.out} ({len(output)} bytes)")
    else:
        sys.stdout.write(output if output.endswith("\n") else output + "\n")
    return 0


if __name__ == "__main__":
    _configure_stdout_utf8()
    raise SystemExit(main())
